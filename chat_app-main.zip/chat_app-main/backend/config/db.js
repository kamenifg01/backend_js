// module.exports = {
//  url : "mongodb://localhost:27017/mongochat"
//   };
module.exports = {
 url : "mongodb+srv://mongochat:WWVwoKHkaas2pULu@cluster0.nzusr.mongodb.net/mongochat?retryWrites=true&w=majority"
  };